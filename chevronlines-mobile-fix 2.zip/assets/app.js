(function(){
var d=document,de=d.documentElement,RM=matchMedia('(prefers-reduced-motion: reduce)').matches,TOUCH=matchMedia('(pointer:coarse)').matches;
de.classList.add('js');
var yr=d.getElementById('yr');if(yr)yr.textContent=new Date().getFullYear();

/* header shadow */
var hd=d.querySelector('.site-header');
function sc(){if(hd)hd.classList.toggle('sc',window.scrollY>8)}sc();addEventListener('scroll',sc,{passive:true});

/* mobile menu: toggle, close on outside tap, Esc, link tap, resize */
var b=d.querySelector('.burger'),n=d.getElementById('nav');
function closeNav(){if(n){n.classList.remove('open')}if(b)b.setAttribute('aria-expanded','false')}
if(b&&n){
b.addEventListener('click',function(e){e.stopPropagation();var o=n.classList.toggle('open');b.setAttribute('aria-expanded',o?'true':'false')});
d.addEventListener('click',function(e){if(n.classList.contains('open')&&!n.contains(e.target)&&!b.contains(e.target))closeNav()});
d.addEventListener('keydown',function(e){if(e.key==='Escape')closeNav()});
addEventListener('resize',function(){if(innerWidth>860)closeNav()});
}

/* client logos that were already cached */
d.querySelectorAll('.clogo').forEach(function(i){if(i.complete&&i.naturalWidth)i.classList.add('ld')});

/* counters */
d.querySelectorAll('[data-count]').forEach(function(e){if(!RM)e.textContent='0'});
function count(el){if(el.dataset.done)return;el.dataset.done=1;var t=+el.dataset.count,s=el.dataset.suffix||'',t0=null,D=RM?1:1800;
function f(ts){t0=t0||ts;var k=Math.min((ts-t0)/D,1),v=Math.round(t*(1-Math.pow(1-k,4)));el.textContent=v+s;if(k<1)requestAnimationFrame(f)}requestAnimationFrame(f)}

/* reveal on scroll (with safe fallback) */
function showAll(){d.querySelectorAll('.rv').forEach(function(e){e.classList.remove('rv')});d.querySelectorAll('[data-count]').forEach(count);d.querySelectorAll('.fill').forEach(function(x){x.style.width=x.dataset.w+'%'})}
if(!('IntersectionObserver' in window)||RM){showAll()}else{
d.querySelectorAll('.rv').forEach(function(e){var sib=[].filter.call(e.parentNode.children,function(x){return x.classList.contains('rv')});
e.style.transitionDelay=(sib.indexOf(e)%4)*90+'ms'});
var io=new IntersectionObserver(function(es){es.forEach(function(e){if(!e.isIntersecting)return;var el=e.target;
requestAnimationFrame(function(){el.classList.add('in')});
if(el.dataset&&el.dataset.count)count(el);
el.querySelectorAll('[data-count]').forEach(count);
el.querySelectorAll('.fill').forEach(function(x){x.style.width=x.dataset.w+'%'});
if(el.classList.contains('rv'))setTimeout(function(){el.classList.remove('rv','in');el.style.transitionDelay=''},1500);
io.unobserve(el)})},{threshold:.05,rootMargin:'0px 0px -4% 0px'});
d.querySelectorAll('.rv,.sgrid').forEach(function(e){io.observe(e)});
setTimeout(function(){d.querySelectorAll('.rv:not(.in)').forEach(function(e){var r=e.getBoundingClientRect();if(r.top<innerHeight&&r.bottom>0)e.classList.add('in')})},2500)}

/* scroll progress bar + background parallax (desktop only) */
if(!RM){var pr=d.createElement('div');pr.className='prog';d.body.appendChild(pr);var bgEl=d.querySelector('.bg'),tick=false;
function up(){tick=false;var y=window.scrollY,h=de.scrollHeight-innerHeight;pr.style.transform='scaleX('+(h>0?Math.min(y/h,1):0)+')';if(bgEl&&!TOUCH)bgEl.style.setProperty('--sy',y)}
addEventListener('scroll',function(){if(!tick){tick=true;requestAnimationFrame(up)}},{passive:true});up()}

/* smooth page transitions, with a safety net so links never get stuck */
function unleave(){de.classList.remove('leaving')}
addEventListener('pageshow',unleave);
d.addEventListener('visibilitychange',function(){if(!d.hidden)unleave()});
if(!RM&&!matchMedia('(pointer:coarse)').matches)d.addEventListener('click',function(e){
if(d.documentElement.classList.contains('leaving')){e.preventDefault();return}
var a=e.target.closest&&e.target.closest('a');if(!a||e.defaultPrevented||e.button||e.metaKey||e.ctrlKey||e.shiftKey||e.altKey)return;
var h=a.getAttribute('href');if(!h||a.target==='_blank'||a.hasAttribute('download')||/^(mailto:|tel:|sms:|#|javascript:)/.test(h))return;
var u;try{u=new URL(a.href,location.href)}catch(x){return}
if(u.origin!==location.origin)return;
if(u.pathname===location.pathname&&u.search===location.search){return}
e.preventDefault();closeNav();de.classList.add('leaving');
setTimeout(function(){location.assign(u.href)},TOUCH?160:280);
setTimeout(unleave,2500)});

/* client search */
var q=d.getElementById('q'),cl=d.getElementById('clist');if(q&&cl){var no=d.getElementById('none');
q.addEventListener('input',function(){var v=q.value.toLowerCase().trim(),c=0;[].forEach.call(cl.children,function(x){var m=x.textContent.toLowerCase().indexOf(v)>-1;x.hidden=!m;if(m)c++});no.hidden=c>0})}

/* contact form */
var f=d.getElementById('cf');if(f){var s=d.getElementById('status');
f.addEventListener('submit',function(e){e.preventDefault();s.className='status';
if(!f.checkValidity()){s.textContent='Please fill in your name, email, message and accept the terms.';s.className='status err';return}
s.textContent='Sending...';
fetch(f.action,{method:'POST',body:new FormData(f),headers:{'X-Requested-With':'fetch'}}).then(function(r){return r.json()}).then(function(j){
if(j.ok){s.textContent='Thank you. Your message has been sent. We will reply soon.';s.className='status ok';f.reset()}else{throw 0}})
.catch(function(){s.textContent='Could not send. Please email us or call the office.';s.className='status err'})})}
})();
